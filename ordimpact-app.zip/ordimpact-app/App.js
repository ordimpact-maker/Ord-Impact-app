// App.js — Navigation principale ORD'IMPACT

import React from 'react';
import { StatusBar, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import HomeScreen    from './src/screens/HomeScreen';
import ServicesScreen from './src/screens/ServicesScreen';
import BookingScreen  from './src/screens/BookingScreen';
import ShopScreen     from './src/screens/ShopScreen';
import ContactScreen  from './src/screens/ContactScreen';
import AuthScreen     from './src/screens/AuthScreen';

import { C } from './src/theme';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

/* Icônes onglets (emoji fallback sans lib externe) */
const TAB_ICONS = {
  Accueil:   { active: '🏠', inactive: '🏠' },
  Services:  { active: '📋', inactive: '📋' },
  Réserver:  { active: '✨', inactive: '✨' },
  Boutique:  { active: '🛒', inactive: '🛒' },
  Contact:   { active: '💬', inactive: '💬' },
  Compte:    { active: '👤', inactive: '👤' },
};

function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#fff',
          borderTopWidth: 1,
          borderTopColor: C.line,
          paddingTop: 6,
          paddingBottom: Platform.OS === 'ios' ? 20 : 8,
          height: Platform.OS === 'ios' ? 82 : 64,
        },
        tabBarActiveTintColor: C.orange,
        tabBarInactiveTintColor: C.muted,
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: '600',
          marginTop: 2,
        },
        tabBarIcon: ({ focused }) => {
          const icons = TAB_ICONS[route.name] || { active: '●', inactive: '○' };
          const size = focused ? 26 : 22;
          return (
            <Text style={{ fontSize: size }}>{focused ? icons.active : icons.inactive}</Text>
          );
        },
      })}
    >
      <Tab.Screen name="Accueil"  component={HomeScreen}     />
      <Tab.Screen name="Services" component={ServicesScreen}  />
      <Tab.Screen
        name="Réserver"
        component={BookingScreen}
        options={{
          tabBarLabel: 'Réserver',
          tabBarStyle: {
            backgroundColor: '#fff',
            borderTopWidth: 1,
            borderTopColor: C.line,
            paddingTop: 6,
            paddingBottom: Platform.OS === 'ios' ? 20 : 8,
            height: Platform.OS === 'ios' ? 82 : 64,
          },
          tabBarItemStyle: {
            backgroundColor: C.orange,
            borderRadius: 14,
            marginHorizontal: 4,
            marginVertical: 4,
          },
          tabBarActiveTintColor: '#fff',
          tabBarInactiveTintColor: '#fff',
          tabBarLabelStyle: {
            fontSize: 10,
            fontWeight: '700',
            color: '#fff',
          },
        }}
      />
      <Tab.Screen name="Boutique" component={ShopScreen}     />
      <Tab.Screen name="Compte"   component={AuthScreen}     />
    </Tab.Navigator>
  );
}

/* Stack pour que Contact soit accessible depuis d'autres écrans */
function RootStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Main"    component={TabNavigator}  />
      <Stack.Screen name="Contact" component={ContactScreen} options={{ presentation: 'modal' }} />
    </Stack.Navigator>
  );
}

import { Text } from 'react-native';

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar barStyle="light-content" backgroundColor={C.navy} />
        <NavigationContainer>
          <TabNavigator />
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
