# ORD'IMPACT — Application Mobile
**React Native / Expo** · Android & iOS

---

## 📱 Écrans inclus

| Écran | Description |
|-------|-------------|
| 🏠 **Accueil** | Hero, services rapides, stats, à propos, boutique promo |
| 📋 **Services** | Présentiel & digital · Accordéon · Réservation directe |
| ✨ **Réserver** | Formulaire 3 étapes · Envoi WhatsApp automatique |
| 🛒 **Boutique** | Produits numériques & physiques · Modal de commande |
| 👤 **Compte** | Connexion · Espace client · Dossiers & factures |

---

## 🚀 Installation rapide (Expo Go — test sur téléphone)

### 1. Prérequis
- Node.js 18+ installé sur votre ordinateur
- L'application **Expo Go** sur votre téléphone (Google Play / App Store)

### 2. Lancer le projet

```bash
# Cloner / décompresser le dossier ordimpact-app
cd ordimpact-app

# Installer les dépendances
npm install

# Lancer Expo
npx expo start
```

### 3. Scanner le QR code
Ouvrez **Expo Go** sur votre téléphone, scannez le QR code affiché → l'app s'ouvre immédiatement !

---

## 📦 Publier sur les stores

### Google Play (Android)

```bash
# Installer EAS (Expo Application Services)
npm install -g eas-cli

# Se connecter à Expo
eas login

# Configurer le build
eas build:configure

# Générer l'APK / AAB pour Google Play
eas build --platform android --profile production
```

Ensuite, uploadez le fichier `.aab` généré dans la [Google Play Console](https://play.google.com/console).

### App Store (iOS)

```bash
# Générer le build iOS (nécessite un compte Apple Developer — 99$/an)
eas build --platform ios --profile production

# Soumettre automatiquement
eas submit --platform ios
```

---

## ⚙️ Configuration avant publication

### app.json — à personnaliser

```json
{
  "expo": {
    "name": "ORD'IMPACT",              ← Nom affiché sur le téléphone
    "ios": {
      "bundleIdentifier": "com.ordimpact.app"   ← Identifiant unique iOS
    },
    "android": {
      "package": "com.ordimpact.app"            ← Package Android
    }
  }
}
```

### Icônes de l'app
Déposez vos images dans `/assets/` :
- `icon.png` — 1024×1024px (icône principale)
- `splash.png` — 1284×2778px (écran de chargement)
- `adaptive-icon.png` — 1024×1024px (Android)

Outil gratuit pour générer les icônes : https://www.appicon.co/

---

## 🔧 Intégrations prévues (prochaines étapes)

| Service | Usage | Statut |
|---------|-------|--------|
| **Stripe** | Paiement en ligne boutique | 🔜 À intégrer |
| **Brevo** | Emails automatiques | 🔜 À intégrer |
| **Google Calendar** | Réservation de créneaux | 🔜 À intégrer |
| **Airtable** | Base de données clients | 🔜 À intégrer |

---

## 📁 Structure du projet

```
ordimpact-app/
├── App.js                    ← Navigation principale
├── app.json                  ← Config Expo
├── package.json              ← Dépendances
├── babel.config.js           ← Config Babel
└── src/
    ├── theme.js              ← Couleurs, ombres, constantes
    ├── data.js               ← Services, produits
    ├── components/
    │   └── UI.js             ← Composants réutilisables
    └── screens/
        ├── HomeScreen.js     ← Accueil
        ├── ServicesScreen.js ← Services
        ├── BookingScreen.js  ← Réservation (3 étapes)
        ← ShopScreen.js      ← Boutique
        ├── AuthScreen.js     ← Espace client
        └── ContactScreen.js  ← Contact & FAQ
```

---

## 🎨 Charte graphique

| Élément | Valeur |
|---------|--------|
| Couleur principale | `#F47820` (orange ORD'IMPACT) |
| Fond sombre | `#001E50` (navy) |
| Fond clair | `#F7F9FC` (cream) |
| Succès | `#16A34A` (vert) |
| Erreur | `#DC2626` (rouge) |

---

## 📞 Support

**ORD'IMPACT** — Chawanda  
📧 ordimpact@gmail.com  
📞 06 94 47 33 22  
📍 44 Rue Albert Darnal, 97300 Cayenne  
SIRET : 103 314 258 00015
