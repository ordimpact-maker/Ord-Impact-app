// src/screens/ServicesScreen.js

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Linking,
} from 'react-native';
import { C, RADIUS, SHADOW } from '../theme';
import { CONTACT } from '../theme';
import { SERVICES_PRESENTIELS, SERVICES_DIGITAUX } from '../data';
import { Card, BtnPrimary, BtnWA, SectionTitle, Tag, PriceBadge } from '../components/UI';

const TABS = ['Présentiel', 'Digital'];

function ServiceCard({ svc, onBook }) {
  const [open, setOpen] = useState(false);
  return (
    <TouchableOpacity
      style={styles.svcCard}
      onPress={() => setOpen(o => !o)}
      activeOpacity={0.88}
    >
      <View style={styles.svcRow}>
        <View style={styles.svcIconWrap}>
          <Text style={{ fontSize: 24 }}>{svc.icon}</Text>
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <Text style={styles.svcLabel}>{svc.label}</Text>
          <PriceBadge price={svc.price} />
        </View>
        <Text style={[styles.chevron, open && { transform: [{ rotate: '90deg' }] }]}>›</Text>
      </View>

      {open && (
        <View style={styles.svcExpand}>
          <Text style={styles.svcDesc}>{svc.desc}</Text>
          <View style={styles.svcActions}>
            <BtnPrimary
              label="Réserver ce service"
              onPress={() => onBook(svc)}
              style={{ flex: 1, marginRight: 8 }}
            />
            <TouchableOpacity
              style={styles.waBtn}
              onPress={() => Linking.openURL(`https://wa.me/${CONTACT.waNumber}?text=Bonjour, je suis intéressé(e) par : ${svc.label}`)}
              activeOpacity={0.82}
            >
              <Text style={{ fontSize: 20 }}>💬</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </TouchableOpacity>
  );
}

export default function ServicesScreen({ navigation }) {
  const [tab, setTab] = useState(0);
  const services = tab === 0 ? SERVICES_PRESENTIELS : SERVICES_DIGITAUX;

  const handleBook = (svc) => {
    navigation.navigate('Réserver', { service: svc });
  };

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Nos services</Text>
        <Text style={styles.headerSub}>Administratif & digital — sur mesure pour vous.</Text>

        {/* Tabs */}
        <View style={styles.tabs}>
          {TABS.map((t, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.tab, tab === i && styles.tabOn]}
              onPress={() => setTab(i)}
              activeOpacity={0.82}
            >
              <Text style={[styles.tabText, tab === i && styles.tabTextOn]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Description tab */}
        <View style={styles.tabDesc}>
          <Text style={styles.tabDescText}>
            {tab === 0
              ? '🏢 Services nécessitant votre présence ou un rendez-vous physique / virtuel.'
              : '💻 Services 100% en ligne, livrés par email ou lien de téléchargement.'}
          </Text>
        </View>

        {/* Services list */}
        <View style={styles.list}>
          {services.map((svc) => (
            <ServiceCard key={svc.id} svc={svc} onBook={handleBook} />
          ))}
        </View>

        {/* CTA bloc */}
        <View style={styles.ctaBlock}>
          <Text style={styles.ctaTitle}>Vous ne trouvez pas ce qu'il vous faut ?</Text>
          <Text style={styles.ctaSub}>Contactez-moi directement, je m'adapte à chaque situation.</Text>
          <BtnWA
            label="Discuter sur WhatsApp"
            onPress={() => Linking.openURL(`https://wa.me/${CONTACT.waNumber}`)}
          />
        </View>

        {/* Prix info */}
        <View style={styles.priceInfo}>
          <Text style={styles.priceInfoTitle}>ℹ️ Informations tarifaires</Text>
          <Text style={styles.priceInfoText}>
            • TVA non applicable — Art. 293B du CGI{'\n'}
            • Devis gratuit sur demande{'\n'}
            • Paiement : virement, espèces, mobile money{'\n'}
            • Facturation ORD'IMPACT (SIRET 103 314 258 00015)
          </Text>
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  header: {
    backgroundColor: C.navy,
    paddingHorizontal: 20,
    paddingTop: 48,
    paddingBottom: 0,
  },
  headerTitle: { fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 5, marginBottom: 20 },
  tabs: { flexDirection: 'row', gap: 6 },
  tab: {
    paddingHorizontal: 22,
    paddingVertical: 10,
    borderRadius: RADIUS.md,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    backgroundColor: 'rgba(255,255,255,0.07)',
  },
  tabOn: { backgroundColor: '#fff' },
  tabText: { fontSize: 13, fontWeight: '600', color: 'rgba(255,255,255,0.55)' },
  tabTextOn: { color: C.navy, fontWeight: '700' },

  scroll: { flex: 1 },
  tabDesc: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: C.line,
  },
  tabDescText: { fontSize: 13, color: C.mid, lineHeight: 20 },

  list: { padding: 16, gap: 10 },

  svcCard: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.lg,
    borderWidth: 1.5,
    borderColor: C.line,
    overflow: 'hidden',
    ...SHADOW.sm,
  },
  svcRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  svcIconWrap: {
    width: 48, height: 48,
    borderRadius: 12,
    backgroundColor: C.warm,
    alignItems: 'center', justifyContent: 'center',
  },
  svcLabel: { fontSize: 14, fontWeight: '700', color: C.navy, marginBottom: 4, lineHeight: 19 },
  chevron: { fontSize: 22, color: C.muted, fontWeight: '300' },

  svcExpand: {
    borderTopWidth: 1,
    borderTopColor: C.line,
    padding: 16,
    backgroundColor: C.cream,
    gap: 12,
  },
  svcDesc: { fontSize: 13, color: C.mid, lineHeight: 20 },
  svcActions: { flexDirection: 'row', alignItems: 'center' },
  waBtn: {
    width: 46, height: 46,
    borderRadius: 12,
    backgroundColor: '#dcfce7',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#bbf7d0',
  },

  ctaBlock: {
    margin: 16,
    backgroundColor: C.warm,
    borderRadius: RADIUS.xl,
    padding: 22,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FDDBB4',
  },
  ctaTitle: { fontSize: 16, fontWeight: '800', color: C.navy, textAlign: 'center', marginBottom: 8 },
  ctaSub: { fontSize: 13, color: C.mid, textAlign: 'center', marginBottom: 16, lineHeight: 19 },

  priceInfo: {
    margin: 16,
    marginTop: 0,
    backgroundColor: '#EFF6FF',
    borderRadius: RADIUS.lg,
    padding: 18,
    borderWidth: 1,
    borderColor: '#BFDBFE',
  },
  priceInfoTitle: { fontSize: 14, fontWeight: '700', color: C.blue, marginBottom: 10 },
  priceInfoText: { fontSize: 13, color: C.mid, lineHeight: 22 },
});
