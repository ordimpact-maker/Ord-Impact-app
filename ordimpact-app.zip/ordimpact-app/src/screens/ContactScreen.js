// src/screens/ContactScreen.js

import React from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Linking,
} from 'react-native';
import { C, RADIUS, SHADOW } from '../theme';
import { CONTACT } from '../theme';

const CONTACT_ITEMS = [
  {
    icon: '💬',
    title: 'WhatsApp',
    sub: 'Réponse rapide garantie',
    value: `+${CONTACT.waNumber}`,
    action: () => Linking.openURL(`https://wa.me/${CONTACT.waNumber}?text=Bonjour, je souhaite un renseignement.`),
    color: '#25D366',
    bg: '#f0fdf4',
    border: '#bbf7d0',
    cta: 'Écrire maintenant →',
  },
  {
    icon: '📞',
    title: 'Téléphone',
    sub: 'Du lundi au vendredi, 8h–18h',
    value: CONTACT.phoneDisplay,
    action: () => Linking.openURL(`tel:${CONTACT.phone}`),
    color: C.blue,
    bg: '#EFF6FF',
    border: '#BFDBFE',
    cta: 'Appeler maintenant →',
  },
  {
    icon: '✉️',
    title: 'Email',
    sub: 'Réponse sous 24h',
    value: CONTACT.email,
    action: () => Linking.openURL(`mailto:${CONTACT.email}?subject=Demande ORD'IMPACT`),
    color: C.purple,
    bg: '#F5F3FF',
    border: '#DDD6FE',
    cta: 'Envoyer un email →',
  },
  {
    icon: '📸',
    title: 'Instagram',
    sub: '@ordimpact',
    value: 'Actualités & témoignages',
    action: () => Linking.openURL(CONTACT.instagram),
    color: '#E1306C',
    bg: '#FFF0F5',
    border: '#FFC8DC',
    cta: 'Voir le profil →',
  },
];

const FAQS = [
  {
    q: 'Combien coûte un diagnostic initial ?',
    a: 'Le diagnostic initial est 100% gratuit et sans engagement. Contactez-moi pour en savoir plus sur votre situation.',
  },
  {
    q: 'Intervenez-vous en dehors de Cayenne ?',
    a: 'Oui ! Les services digitaux sont disponibles partout en Guyane et dans les DOM. Certains services présentiel peuvent être organisés en déplacement.',
  },
  {
    q: 'Quels modes de paiement acceptez-vous ?',
    a: 'Virement bancaire, espèces, et mobile money. Stripe sera bientôt disponible pour le paiement en ligne.',
  },
  {
    q: 'Combien de temps durent les démarches ?',
    a: 'Cela dépend du service. La carte grise peut être traitée en 24h. D\'autres dossiers (naturalisation, immigration) nécessitent plusieurs semaines selon l\'administration.',
  },
  {
    q: 'Mes données sont-elles confidentielles ?',
    a: 'Absolument. Toutes vos informations sont traitées avec la plus grande discrétion et ne sont jamais partagées avec des tiers.',
  },
];

function FaqItem({ q, a }) {
  const [open, setOpen] = React.useState(false);
  return (
    <TouchableOpacity style={styles.faqItem} onPress={() => setOpen(o => !o)} activeOpacity={0.85}>
      <View style={styles.faqRow}>
        <Text style={styles.faqQ}>{q}</Text>
        <Text style={[styles.faqChevron, open && { transform: [{ rotate: '90deg' }] }]}>›</Text>
      </View>
      {open && <Text style={styles.faqA}>{a}</Text>}
    </TouchableOpacity>
  );
}

export default function ContactScreen({ navigation }) {
  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Contact</Text>
        <Text style={styles.headerSub}>Disponible du lundi au vendredi · Guyane française</Text>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Carte identité */}
        <View style={styles.identCard}>
          <View style={styles.avatar}>
            <Text style={{ fontSize: 36 }}>👩🏽‍💼</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.identName}>Chawanda</Text>
            <Text style={styles.identRole}>Gérante — ORD'IMPACT</Text>
            <Text style={styles.identSiret}>SIRET : 103 314 258 00015</Text>
          </View>
        </View>

        {/* Canaux de contact */}
        <View style={styles.section}>
          {CONTACT_ITEMS.map((item, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.contactCard, { backgroundColor: item.bg, borderColor: item.border }]}
              onPress={item.action}
              activeOpacity={0.85}
            >
              <View style={styles.contactRow}>
                <View style={[styles.contactIcon, { backgroundColor: item.color + '18' }]}>
                  <Text style={{ fontSize: 24 }}>{item.icon}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.contactTitle, { color: item.color }]}>{item.title}</Text>
                  <Text style={styles.contactSub}>{item.sub}</Text>
                  <Text style={styles.contactVal}>{item.value}</Text>
                </View>
                <Text style={[styles.contactCta, { color: item.color }]}>{item.cta}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Adresse */}
        <View style={styles.addressCard}>
          <Text style={styles.addressIcon}>📍</Text>
          <View>
            <Text style={styles.addressTitle}>Adresse</Text>
            <Text style={styles.addressVal}>{CONTACT.address}</Text>
            <Text style={styles.addressNote}>Guyane française — 973</Text>
          </View>
        </View>

        {/* Horaires */}
        <View style={styles.hoursCard}>
          <Text style={styles.hoursTitle}>🕐 Horaires d'ouverture</Text>
          {[
            ['Lundi – Vendredi', '8h00 – 18h00'],
            ['Samedi', '9h00 – 13h00'],
            ['Dimanche', 'Fermé'],
          ].map(([day, hours]) => (
            <View key={day} style={styles.hoursRow}>
              <Text style={styles.hoursDay}>{day}</Text>
              <Text style={[styles.hoursVal, hours === 'Fermé' && { color: C.red }]}>{hours}</Text>
            </View>
          ))}
          <Text style={styles.hoursNote}>* WhatsApp disponible en dehors des horaires pour les urgences.</Text>
        </View>

        {/* FAQ */}
        <View style={styles.faqSection}>
          <Text style={styles.faqTitle}>Questions fréquentes</Text>
          {FAQS.map((faq, i) => <FaqItem key={i} {...faq} />)}
        </View>

        {/* Diagnostic CTA */}
        <View style={styles.diagCta}>
          <Text style={{ fontSize: 32, marginBottom: 10 }}>🎁</Text>
          <Text style={styles.diagCtaTitle}>Diagnostic gratuit</Text>
          <Text style={styles.diagCtaSub}>Première consultation sans engagement pour évaluer votre dossier.</Text>
          <TouchableOpacity
            style={styles.diagBtn}
            onPress={() => navigation.navigate('Réserver')}
            activeOpacity={0.85}
          >
            <Text style={styles.diagBtnText}>Prendre rendez-vous →</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  header: {
    backgroundColor: C.navy,
    paddingHorizontal: 20,
    paddingTop: 48,
    paddingBottom: 24,
  },
  headerTitle: { fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 5 },

  scroll: { flex: 1 },

  identCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: '#fff',
    margin: 16,
    borderRadius: RADIUS.xl,
    padding: 20,
    borderWidth: 1.5,
    borderColor: C.line,
    ...SHADOW.sm,
  },
  avatar: {
    width: 68, height: 68, borderRadius: 34,
    backgroundColor: C.warm,
    alignItems: 'center', justifyContent: 'center',
  },
  identName: { fontSize: 20, fontWeight: '900', color: C.navy },
  identRole: { fontSize: 13, color: C.orange, fontWeight: '700', marginTop: 2 },
  identSiret: { fontSize: 11, color: C.muted, marginTop: 4, fontWeight: '500' },

  section: { paddingHorizontal: 16, gap: 10, marginBottom: 16 },

  contactCard: {
    borderRadius: RADIUS.lg,
    borderWidth: 1.5,
    padding: 16,
    ...SHADOW.sm,
  },
  contactRow: { gap: 8 },
  contactIcon: {
    width: 50, height: 50, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 8,
  },
  contactTitle: { fontSize: 16, fontWeight: '800', marginBottom: 2 },
  contactSub: { fontSize: 12, color: C.muted, fontWeight: '500', marginBottom: 4 },
  contactVal: { fontSize: 14, fontWeight: '700', color: C.navy, marginBottom: 8 },
  contactCta: { fontSize: 13, fontWeight: '700' },

  addressCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    backgroundColor: '#fff',
    marginHorizontal: 16,
    borderRadius: RADIUS.lg,
    padding: 18,
    borderWidth: 1.5,
    borderColor: C.line,
    marginBottom: 12,
    ...SHADOW.sm,
  },
  addressIcon: { fontSize: 24 },
  addressTitle: { fontSize: 14, fontWeight: '800', color: C.navy, marginBottom: 4 },
  addressVal: { fontSize: 14, color: C.mid, lineHeight: 20 },
  addressNote: { fontSize: 11, color: C.muted, marginTop: 3, fontWeight: '500' },

  hoursCard: {
    backgroundColor: '#fff',
    marginHorizontal: 16,
    borderRadius: RADIUS.lg,
    padding: 18,
    borderWidth: 1.5,
    borderColor: C.line,
    marginBottom: 12,
    ...SHADOW.sm,
  },
  hoursTitle: { fontSize: 14, fontWeight: '800', color: C.navy, marginBottom: 14 },
  hoursRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: C.line,
  },
  hoursDay: { fontSize: 13, color: C.mid, fontWeight: '500' },
  hoursVal: { fontSize: 13, fontWeight: '700', color: C.navy },
  hoursNote: { fontSize: 11, color: C.muted, marginTop: 10, lineHeight: 17 },

  faqSection: { paddingHorizontal: 16, marginBottom: 16 },
  faqTitle: { fontSize: 18, fontWeight: '800', color: C.navy, marginBottom: 14 },
  faqItem: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.lg,
    borderWidth: 1.5,
    borderColor: C.line,
    padding: 16,
    marginBottom: 8,
    ...SHADOW.sm,
  },
  faqRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  faqQ: { flex: 1, fontSize: 14, fontWeight: '700', color: C.navy, lineHeight: 20 },
  faqChevron: { fontSize: 22, color: C.muted },
  faqA: { fontSize: 13, color: C.mid, lineHeight: 21, marginTop: 10 },

  diagCta: {
    backgroundColor: C.navy,
    margin: 16,
    borderRadius: RADIUS.xl,
    padding: 28,
    alignItems: 'center',
    ...SHADOW.lg,
  },
  diagCtaTitle: { fontSize: 22, fontWeight: '900', color: '#fff', marginBottom: 8, textAlign: 'center' },
  diagCtaSub: { fontSize: 13, color: 'rgba(255,255,255,0.65)', textAlign: 'center', marginBottom: 22, lineHeight: 20 },
  diagBtn: {
    backgroundColor: C.orange,
    borderRadius: RADIUS.md,
    paddingHorizontal: 24,
    paddingVertical: 14,
  },
  diagBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
