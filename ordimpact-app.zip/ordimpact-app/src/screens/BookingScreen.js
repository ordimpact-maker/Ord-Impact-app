// src/screens/BookingScreen.js

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  TextInput, Alert, Linking,
} from 'react-native';
import { C, RADIUS, SHADOW } from '../theme';
import { CONTACT } from '../theme';
import { SERVICES_PRESENTIELS, SERVICES_DIGITAUX, PHONE_PREFIXES } from '../data';
import { BtnPrimary, BtnWA, Card } from '../components/UI';

const ALL_SERVICES = [...SERVICES_PRESENTIELS, ...SERVICES_DIGITAUX];

const SLOTS = ['Matin (8h–12h)', 'Après-midi (13h–17h)', 'Soirée (17h–19h)', 'Flexible'];

function Field({ label, value, onChange, placeholder, keyboardType, multiline, required }) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={fStyles.wrap}>
      <Text style={fStyles.label}>{label}{required && <Text style={{ color: C.red }}> *</Text>}</Text>
      <TextInput
        style={[fStyles.input, focused && fStyles.focused, multiline && fStyles.multiline]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={C.muted}
        keyboardType={keyboardType || 'default'}
        multiline={multiline}
        numberOfLines={multiline ? 3 : 1}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        autoCapitalize="none"
      />
    </View>
  );
}

const fStyles = StyleSheet.create({
  wrap: { marginBottom: 14 },
  label: { fontSize: 12.5, fontWeight: '700', color: C.navy, marginBottom: 6 },
  input: {
    fontFamily: undefined,
    fontSize: 14,
    padding: 13,
    borderRadius: RADIUS.md,
    borderWidth: 1.5,
    borderColor: C.line,
    backgroundColor: C.cream,
    color: C.dark,
  },
  focused: { borderColor: C.blue, backgroundColor: '#fff' },
  multiline: { height: 80, textAlignVertical: 'top' },
});

export default function BookingScreen({ route }) {
  const preselected = route?.params?.service || null;

  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    prenom: '', nom: '', email: '', phone: '',
    prefix: '+594', service: preselected?.label || '',
    slot: '', message: '',
  });
  const [done, setDone] = useState(false);

  const upd = (k) => (v) => setForm(f => ({ ...f, [k]: v }));

  const isStep1Valid = form.prenom.trim().length >= 2 && form.nom.trim().length >= 2
    && /\S+@\S+\.\S+/.test(form.email) && form.phone.replace(/\D/g, '').length >= 6;
  const isStep2Valid = form.service.length > 0;

  const submit = () => {
    const msg = `Bonjour Chawanda,%0A%0AJe souhaite prendre rendez-vous :%0A%0A👤 ${form.prenom} ${form.nom}%0A📧 ${form.email}%0A📞 ${form.prefix} ${form.phone}%0A📋 Service : ${form.service}%0A🕐 Créneau : ${form.slot || 'Flexible'}%0A%0A💬 ${form.message || 'Pas de message complémentaire.'}`;
    Linking.openURL(`https://wa.me/${CONTACT.waNumber}?text=${msg}`);
    setDone(true);
  };

  if (done) {
    return (
      <View style={styles.donePage}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>✅</Text>
        <Text style={styles.doneTitle}>Demande envoyée !</Text>
        <Text style={styles.doneSub}>
          Votre demande a été transmise via WhatsApp.{'\n'}
          Je vous réponds sous 24h maximum.
        </Text>
        <View style={styles.doneInfo}>
          <Text style={styles.doneInfoText}>📧 {form.email}</Text>
          <Text style={styles.doneInfoText}>📋 {form.service}</Text>
        </View>
        <BtnPrimary
          label="Faire une nouvelle demande"
          onPress={() => { setDone(false); setStep(1); setForm({ prenom:'',nom:'',email:'',phone:'',prefix:'+594',service:'',slot:'',message:'' }); }}
        />
      </View>
    );
  }

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Réserver</Text>
        <Text style={styles.headerSub}>Diagnostic gratuit · Réponse sous 24h</Text>

        {/* Étapes */}
        <View style={styles.steps}>
          {[1, 2, 3].map(s => (
            <React.Fragment key={s}>
              <View style={[styles.step, step >= s && styles.stepOn]}>
                <Text style={[styles.stepN, step >= s && styles.stepNOn]}>{s}</Text>
              </View>
              {s < 3 && <View style={[styles.stepLine, step > s && styles.stepLineOn]} />}
            </React.Fragment>
          ))}
        </View>
        <View style={styles.stepLabels}>
          {['Identité', 'Service', 'Confirmation'].map((l, i) => (
            <Text key={i} style={[styles.stepLabel, step === i + 1 && styles.stepLabelOn]}>{l}</Text>
          ))}
        </View>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* ── ÉTAPE 1 : Identité ── */}
        {step === 1 && (
          <View style={styles.form}>
            <Text style={styles.formTitle}>Vos coordonnées</Text>

            <View style={styles.row}>
              <View style={{ flex: 1 }}>
                <Field label="Prénom" value={form.prenom} onChange={upd('prenom')} placeholder="Marie" required />
              </View>
              <View style={{ width: 12 }} />
              <View style={{ flex: 1 }}>
                <Field label="Nom" value={form.nom} onChange={upd('nom')} placeholder="Dupont" required />
              </View>
            </View>

            <Field label="Email" value={form.email} onChange={upd('email')} placeholder="votre@email.fr" keyboardType="email-address" required />

            {/* Téléphone avec préfixe */}
            <View style={fStyles.wrap}>
              <Text style={fStyles.label}>Téléphone <Text style={{ color: C.red }}>*</Text></Text>
              <View style={styles.phoneRow}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.prefixScroll}>
                  {PHONE_PREFIXES.map(p => (
                    <TouchableOpacity
                      key={p.code}
                      style={[styles.prefixChip, form.prefix === p.code && styles.prefixOn]}
                      onPress={() => upd('prefix')(p.code)}
                      activeOpacity={0.8}
                    >
                      <Text style={{ fontSize: 16 }}>{p.flag}</Text>
                      <Text style={[styles.prefixCode, form.prefix === p.code && { color: C.orange }]}>{p.code}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <TextInput
                  style={[fStyles.input, { flex: 1, marginTop: 8 }]}
                  value={form.phone}
                  onChangeText={upd('phone')}
                  placeholder="694 47 33 22"
                  placeholderTextColor={C.muted}
                  keyboardType="phone-pad"
                />
              </View>
            </View>

            <BtnPrimary
              label="Continuer →"
              onPress={() => setStep(2)}
              disabled={!isStep1Valid}
            />
          </View>
        )}

        {/* ── ÉTAPE 2 : Service ── */}
        {step === 2 && (
          <View style={styles.form}>
            <Text style={styles.formTitle}>Choisissez votre service</Text>

            <Text style={styles.svcGroupLabel}>📁 Services présentiel</Text>
            {SERVICES_PRESENTIELS.map(s => (
              <TouchableOpacity
                key={s.id}
                style={[styles.svcChoice, form.service === s.label && styles.svcChoiceOn]}
                onPress={() => upd('service')(s.label)}
                activeOpacity={0.82}
              >
                <Text style={{ fontSize: 20 }}>{s.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.svcChoiceLabel}>{s.label}</Text>
                  <Text style={styles.svcChoicePrice}>{s.price}</Text>
                </View>
                {form.service === s.label && <Text style={{ color: C.orange, fontWeight: '900', fontSize: 18 }}>✓</Text>}
              </TouchableOpacity>
            ))}

            <Text style={[styles.svcGroupLabel, { marginTop: 16 }]}>💻 Services digital</Text>
            {SERVICES_DIGITAUX.map(s => (
              <TouchableOpacity
                key={s.id}
                style={[styles.svcChoice, form.service === s.label && styles.svcChoiceOn]}
                onPress={() => upd('service')(s.label)}
                activeOpacity={0.82}
              >
                <Text style={{ fontSize: 20 }}>{s.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.svcChoiceLabel}>{s.label}</Text>
                  <Text style={styles.svcChoicePrice}>{s.price}</Text>
                </View>
                {form.service === s.label && <Text style={{ color: C.orange, fontWeight: '900', fontSize: 18 }}>✓</Text>}
              </TouchableOpacity>
            ))}

            <Text style={[styles.svcGroupLabel, { marginTop: 16 }]}>🕐 Créneau souhaité</Text>
            <View style={styles.slotsGrid}>
              {SLOTS.map(sl => (
                <TouchableOpacity
                  key={sl}
                  style={[styles.slotChip, form.slot === sl && styles.slotOn]}
                  onPress={() => upd('slot')(sl)}
                  activeOpacity={0.82}
                >
                  <Text style={[styles.slotText, form.slot === sl && { color: C.orange, fontWeight: '700' }]}>{sl}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.navRow}>
              <TouchableOpacity style={styles.backBtn} onPress={() => setStep(1)}>
                <Text style={styles.backBtnText}>← Retour</Text>
              </TouchableOpacity>
              <BtnPrimary label="Continuer →" onPress={() => setStep(3)} disabled={!isStep2Valid} style={{ flex: 1 }} />
            </View>
          </View>
        )}

        {/* ── ÉTAPE 3 : Confirmation ── */}
        {step === 3 && (
          <View style={styles.form}>
            <Text style={styles.formTitle}>Confirmation</Text>

            <Field
              label="Message complémentaire (optionnel)"
              value={form.message}
              onChange={upd('message')}
              placeholder="Décrivez votre situation en quelques mots..."
              multiline
            />

            {/* Récapitulatif */}
            <View style={styles.recap}>
              <Text style={styles.recapTitle}>📋 Récapitulatif</Text>
              {[
                ['👤 Nom', `${form.prenom} ${form.nom}`],
                ['📧 Email', form.email],
                ['📞 Tél.', `${form.prefix} ${form.phone}`],
                ['🛠️ Service', form.service],
                ['🕐 Créneau', form.slot || 'Flexible'],
              ].map(([k, v]) => (
                <View key={k} style={styles.recapRow}>
                  <Text style={styles.recapKey}>{k}</Text>
                  <Text style={styles.recapVal} numberOfLines={2}>{v}</Text>
                </View>
              ))}
            </View>

            <View style={styles.diagFree}>
              <Text style={styles.diagFreeText}>🎁 Le diagnostic initial est 100% gratuit et sans engagement.</Text>
            </View>

            <View style={styles.navRow}>
              <TouchableOpacity style={styles.backBtn} onPress={() => setStep(2)}>
                <Text style={styles.backBtnText}>← Retour</Text>
              </TouchableOpacity>
              <BtnWA label="Envoyer via WhatsApp" onPress={submit} style={{ flex: 1 }} />
            </View>

            <Text style={styles.altContact}>
              Ou par email : {CONTACT.email}
            </Text>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },

  header: {
    backgroundColor: C.navy,
    paddingHorizontal: 20,
    paddingTop: 48,
    paddingBottom: 24,
  },
  headerTitle: { fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 5, marginBottom: 22 },

  steps: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  step: {
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.2)',
  },
  stepOn: { backgroundColor: C.orange, borderColor: C.orange },
  stepN: { fontSize: 13, fontWeight: '700', color: 'rgba(255,255,255,0.4)' },
  stepNOn: { color: '#fff' },
  stepLine: { flex: 1, height: 2, backgroundColor: 'rgba(255,255,255,0.15)', marginHorizontal: 6 },
  stepLineOn: { backgroundColor: C.orange },
  stepLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  stepLabel: { fontSize: 11, color: 'rgba(255,255,255,0.4)', fontWeight: '600', flex: 1, textAlign: 'center' },
  stepLabelOn: { color: C.orange },

  scroll: { flex: 1 },
  form: { padding: 20, gap: 0 },
  formTitle: { fontSize: 19, fontWeight: '800', color: C.navy, marginBottom: 20 },

  row: { flexDirection: 'row' },

  phoneRow: { gap: 0 },
  prefixScroll: { marginBottom: 0 },
  prefixChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 7,
    borderRadius: 8, borderWidth: 1.5, borderColor: C.line,
    backgroundColor: '#fff', marginRight: 6, marginBottom: 0,
  },
  prefixOn: { borderColor: C.orange, backgroundColor: C.warm },
  prefixCode: { fontSize: 12, fontWeight: '700', color: C.mid },

  svcGroupLabel: { fontSize: 12, fontWeight: '700', color: C.muted, letterSpacing: 0.5, marginBottom: 10, textTransform: 'uppercase' },
  svcChoice: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 14,
    backgroundColor: '#fff',
    borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: C.line,
    marginBottom: 8,
    ...SHADOW.sm,
  },
  svcChoiceOn: { borderColor: C.orange, backgroundColor: C.warm },
  svcChoiceLabel: { fontSize: 13, fontWeight: '700', color: C.navy, marginBottom: 2 },
  svcChoicePrice: { fontSize: 12, fontWeight: '600', color: C.orange },

  slotsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  slotChip: {
    paddingHorizontal: 14, paddingVertical: 9,
    borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: C.line,
    backgroundColor: '#fff',
  },
  slotOn: { borderColor: C.orange, backgroundColor: C.warm },
  slotText: { fontSize: 13, fontWeight: '500', color: C.mid },

  navRow: { flexDirection: 'row', gap: 10, marginTop: 8, marginBottom: 12 },
  backBtn: {
    paddingHorizontal: 18, paddingVertical: 14,
    borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: C.line,
    backgroundColor: '#fff',
    alignItems: 'center', justifyContent: 'center',
  },
  backBtnText: { fontSize: 13, fontWeight: '600', color: C.mid },

  recap: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.lg,
    padding: 18,
    borderWidth: 1.5, borderColor: C.line,
    marginBottom: 14,
    gap: 10,
    ...SHADOW.sm,
  },
  recapTitle: { fontSize: 14, fontWeight: '800', color: C.navy, marginBottom: 4 },
  recapRow: { flexDirection: 'row', gap: 12 },
  recapKey: { fontSize: 12, fontWeight: '700', color: C.muted, width: 90 },
  recapVal: { fontSize: 13, color: C.navy, flex: 1, fontWeight: '500' },

  diagFree: {
    backgroundColor: '#f0fdf4',
    borderRadius: RADIUS.md,
    padding: 14,
    borderWidth: 1, borderColor: '#bbf7d0',
    marginBottom: 16,
  },
  diagFreeText: { fontSize: 13, color: C.green, fontWeight: '600', lineHeight: 19 },

  altContact: { fontSize: 12, color: C.muted, textAlign: 'center', marginTop: 12 },

  /* Done page */
  donePage: {
    flex: 1, backgroundColor: '#fff',
    alignItems: 'center', justifyContent: 'center',
    padding: 32,
  },
  doneTitle: { fontSize: 26, fontWeight: '900', color: C.navy, marginBottom: 12 },
  doneSub: { fontSize: 15, color: C.mid, textAlign: 'center', lineHeight: 23, marginBottom: 24 },
  doneInfo: {
    backgroundColor: C.cream, borderRadius: RADIUS.lg,
    padding: 18, borderWidth: 1, borderColor: C.line,
    width: '100%', marginBottom: 24, gap: 8,
  },
  doneInfoText: { fontSize: 14, color: C.navy, fontWeight: '600' },
});
