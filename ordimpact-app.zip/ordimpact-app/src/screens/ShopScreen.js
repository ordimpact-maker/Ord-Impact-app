// src/screens/ShopScreen.js

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Modal, Linking, TextInput, Alert,
} from 'react-native';
import { C, RADIUS, SHADOW } from '../theme';
import { CONTACT } from '../theme';
import { DIGITAL_PRODUCTS, PHYSIQUE_PRODUCTS } from '../data';
import { BtnPrimary, Card, Tag, SectionTitle } from '../components/UI';

const TABS = ['Produits numériques', 'Articles physiques'];

/* ── Modal paiement numérique ── */
function ModalDigital({ product, onClose }) {
  const [form, setForm] = useState({ prenom: '', nom: '', email: '' });
  const [done, setDone] = useState(false);

  const valid = form.prenom.trim().length >= 2 && form.nom.trim().length >= 2
    && /\S+@\S+\.\S+/.test(form.email);

  const handlePay = () => {
    const msg = `Bonjour,%0AJe souhaite acquérir : *${product.name}* (${product.price} €)%0A%0ANom : ${form.prenom} ${form.nom}%0AEmail : ${form.email}%0A%0AMerci de m'indiquer les modalités de paiement.`;
    Linking.openURL(`https://wa.me/${CONTACT.waNumber}?text=${msg}`);
    setDone(true);
  };

  if (done) {
    return (
      <View style={mStyles.doneWrap}>
        <Text style={{ fontSize: 52, marginBottom: 12 }}>✅</Text>
        <Text style={mStyles.doneTitle}>Demande envoyée !</Text>
        <Text style={mStyles.doneSub}>
          Je vous envoie le lien de téléchargement après réception du paiement.
        </Text>
        <TouchableOpacity style={mStyles.closeBtn} onPress={onClose}>
          <Text style={mStyles.closeBtnText}>Fermer</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={mStyles.body}>
      <View style={mStyles.prodHeader}>
        <Text style={{ fontSize: 36 }}>{product.emoji}</Text>
        <View style={{ flex: 1 }}>
          <Text style={mStyles.prodName}>{product.name}</Text>
          <Text style={mStyles.prodPrice}>{product.price} € · Accès immédiat</Text>
        </View>
      </View>

      <View style={mStyles.secureNote}>
        <Text style={mStyles.secureText}>🔒 Commande via WhatsApp → paiement → lien envoyé par email</Text>
      </View>

      <View style={mStyles.row}>
        <View style={{ flex: 1 }}>
          <Text style={mStyles.label}>Prénom *</Text>
          <TextInput style={mStyles.input} value={form.prenom} onChangeText={v => setForm(f => ({ ...f, prenom: v }))} placeholder="Marie" placeholderTextColor={C.muted} />
        </View>
        <View style={{ width: 10 }} />
        <View style={{ flex: 1 }}>
          <Text style={mStyles.label}>Nom *</Text>
          <TextInput style={mStyles.input} value={form.nom} onChangeText={v => setForm(f => ({ ...f, nom: v }))} placeholder="Dupont" placeholderTextColor={C.muted} />
        </View>
      </View>

      <Text style={mStyles.label}>Email * (réception du lien)</Text>
      <TextInput
        style={[mStyles.input, { marginBottom: 16 }]}
        value={form.email}
        onChangeText={v => setForm(f => ({ ...f, email: v }))}
        placeholder="votre@email.fr"
        placeholderTextColor={C.muted}
        keyboardType="email-address"
        autoCapitalize="none"
      />

      <View style={mStyles.totalRow}>
        <Text style={mStyles.totalLabel}>Total</Text>
        <Text style={mStyles.totalVal}>{product.price} €</Text>
      </View>

      <BtnPrimary
        label={`💬 Commander via WhatsApp — ${product.price} €`}
        onPress={handlePay}
        disabled={!valid}
        style={{ marginTop: 12 }}
      />
    </View>
  );
}

/* ── Modal commande physique ── */
function ModalPhysical({ product, onClose }) {
  const [form, setForm] = useState({ prenom: '', nom: '', email: '', adresse: '', ville: '' });
  const [done, setDone] = useState(false);

  const valid = form.prenom && form.nom && /\S+@\S+\.\S+/.test(form.email) && form.adresse && form.ville;

  const handleOrder = () => {
    const msg = `Bonjour,%0ACommande : *${product.name}* (${product.price} €)%0A%0ANom : ${form.prenom} ${form.nom}%0AEmail : ${form.email}%0ALivraison : ${form.adresse}, ${form.ville}`;
    Linking.openURL(`https://wa.me/${CONTACT.waNumber}?text=${msg}`);
    setDone(true);
  };

  if (done) {
    return (
      <View style={mStyles.doneWrap}>
        <Text style={{ fontSize: 52, marginBottom: 12 }}>🚚</Text>
        <Text style={mStyles.doneTitle}>Commande transmise !</Text>
        <Text style={mStyles.doneSub}>Je vous confirme les délais de livraison sous 24h.</Text>
        <TouchableOpacity style={mStyles.closeBtn} onPress={onClose}>
          <Text style={mStyles.closeBtnText}>Fermer</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={mStyles.body}>
      <View style={mStyles.prodHeader}>
        <Text style={{ fontSize: 36 }}>{product.emoji}</Text>
        <View style={{ flex: 1 }}>
          <Text style={mStyles.prodName}>{product.name}</Text>
          <Text style={mStyles.prodPrice}>{product.price} € · Livraison à domicile</Text>
        </View>
      </View>

      <View style={[mStyles.secureNote, { backgroundColor: '#EFF6FF', borderColor: '#BFDBFE' }]}>
        <Text style={[mStyles.secureText, { color: C.blue }]}>🚚 Livré directement chez vous via notre partenaire logistique.</Text>
      </View>

      <Text style={mStyles.label}>Adresse de livraison *</Text>
      <TextInput style={mStyles.input} value={form.adresse} onChangeText={v => setForm(f => ({ ...f, adresse: v }))} placeholder="12 Rue des Palmistes" placeholderTextColor={C.muted} />

      <View style={mStyles.row}>
        <View style={{ flex: 1 }}>
          <Text style={mStyles.label}>Prénom *</Text>
          <TextInput style={mStyles.input} value={form.prenom} onChangeText={v => setForm(f => ({ ...f, prenom: v }))} placeholder="Marie" placeholderTextColor={C.muted} />
        </View>
        <View style={{ width: 10 }} />
        <View style={{ flex: 1 }}>
          <Text style={mStyles.label}>Ville *</Text>
          <TextInput style={mStyles.input} value={form.ville} onChangeText={v => setForm(f => ({ ...f, ville: v }))} placeholder="Cayenne" placeholderTextColor={C.muted} />
        </View>
      </View>

      <Text style={mStyles.label}>Email *</Text>
      <TextInput
        style={[mStyles.input, { marginBottom: 16 }]}
        value={form.email}
        onChangeText={v => setForm(f => ({ ...f, email: v }))}
        placeholder="votre@email.fr"
        placeholderTextColor={C.muted}
        keyboardType="email-address"
        autoCapitalize="none"
      />

      <View style={mStyles.totalRow}>
        <Text style={mStyles.totalLabel}>Total produit</Text>
        <Text style={mStyles.totalVal}>{product.price} €</Text>
      </View>
      <Text style={{ fontSize: 11, color: C.muted, marginTop: 3, marginBottom: 12 }}>+ frais de livraison selon zone</Text>

      <BtnPrimary label={`🛒 Commander — ${product.price} €`} onPress={handleOrder} disabled={!valid} />
    </View>
  );
}

export default function ShopScreen() {
  const [tab, setTab] = useState(0);
  const [modal, setModal] = useState(null);

  const products = tab === 0 ? DIGITAL_PRODUCTS : PHYSIQUE_PRODUCTS;

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Boutique</Text>
        <Text style={styles.headerSub}>Produits numériques & articles pratiques.</Text>
        <View style={styles.tabs}>
          {TABS.map((t, i) => (
            <TouchableOpacity key={i} style={[styles.tab, tab === i && styles.tabOn]} onPress={() => setTab(i)} activeOpacity={0.82}>
              <Text style={[styles.tabText, tab === i && styles.tabTextOn]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {tab === 0 && (
          <View style={styles.notice}>
            <Text style={styles.noticeText}>⚡ Accès immédiat après paiement — lien envoyé par email</Text>
          </View>
        )}
        {tab === 1 && (
          <View style={[styles.notice, { backgroundColor: '#EFF6FF', borderColor: '#BFDBFE' }]}>
            <Text style={[styles.noticeText, { color: C.blue }]}>🚚 Livraison à domicile · Délai selon zone</Text>
          </View>
        )}

        <View style={styles.grid}>
          {products.map(p => (
            <TouchableOpacity key={p.id} style={styles.prodCard} onPress={() => setModal(p)} activeOpacity={0.88}>
              <View style={styles.prodEmoji}>
                <Text style={{ fontSize: 32 }}>{p.emoji}</Text>
              </View>
              <View style={styles.prodCatRow}>
                <Tag label={p.cat} color={C.blue} bg="#EFF6FF" />
              </View>
              <Text style={styles.prodName}>{p.name}</Text>
              <Text style={styles.prodDesc} numberOfLines={2}>{p.desc}</Text>
              <View style={styles.prodFooter}>
                <Text style={styles.prodPrice}>{p.price} €</Text>
                <View style={styles.prodBtn}>
                  <Text style={styles.prodBtnText}>{tab === 0 ? 'Obtenir →' : 'Commander →'}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>

      {/* Modal */}
      <Modal visible={!!modal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setModal(null)}>
        <View style={styles.modalWrap}>
          <TouchableOpacity style={styles.modalClose} onPress={() => setModal(null)}>
            <Text style={styles.modalCloseText}>✕</Text>
          </TouchableOpacity>
          <ScrollView showsVerticalScrollIndicator={false}>
            {modal && tab === 0
              ? <ModalDigital product={modal} onClose={() => setModal(null)} />
              : modal && <ModalPhysical product={modal} onClose={() => setModal(null)} />
            }
            <View style={{ height: 40 }} />
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  header: {
    backgroundColor: C.navy,
    paddingHorizontal: 20,
    paddingTop: 48,
    paddingBottom: 0,
  },
  headerTitle: { fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 5, marginBottom: 20 },
  tabs: { flexDirection: 'row', gap: 6 },
  tab: {
    flex: 1, paddingVertical: 10,
    borderRadius: RADIUS.md,
    borderBottomLeftRadius: 0, borderBottomRightRadius: 0,
    backgroundColor: 'rgba(255,255,255,0.07)',
    alignItems: 'center',
  },
  tabOn: { backgroundColor: '#fff' },
  tabText: { fontSize: 12, fontWeight: '600', color: 'rgba(255,255,255,0.55)' },
  tabTextOn: { color: C.navy, fontWeight: '700' },

  scroll: { flex: 1 },
  notice: {
    backgroundColor: '#f0fdf4',
    borderWidth: 1, borderColor: '#bbf7d0',
    paddingHorizontal: 20, paddingVertical: 12,
  },
  noticeText: { fontSize: 13, fontWeight: '600', color: C.green },

  grid: { padding: 16, gap: 12 },
  prodCard: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.xl,
    borderWidth: 1.5, borderColor: C.line,
    padding: 20,
    ...SHADOW.sm,
  },
  prodEmoji: {
    width: 60, height: 60, borderRadius: 16,
    backgroundColor: C.warm,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 12,
  },
  prodCatRow: { marginBottom: 8 },
  prodName: { fontSize: 16, fontWeight: '800', color: C.navy, marginBottom: 6, lineHeight: 21 },
  prodDesc: { fontSize: 13, color: C.mid, lineHeight: 19, marginBottom: 14 },
  prodFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  prodPrice: { fontSize: 20, fontWeight: '900', color: C.orange },
  prodBtn: {
    backgroundColor: C.warm,
    borderRadius: RADIUS.md,
    paddingHorizontal: 16, paddingVertical: 8,
    borderWidth: 1, borderColor: '#FDDBB4',
  },
  prodBtnText: { fontSize: 13, fontWeight: '700', color: C.orange },

  modalWrap: { flex: 1, backgroundColor: '#fff' },
  modalClose: {
    position: 'absolute', top: 16, right: 16, zIndex: 10,
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: C.cream,
    alignItems: 'center', justifyContent: 'center',
    ...SHADOW.sm,
  },
  modalCloseText: { fontSize: 16, color: C.mid, fontWeight: '700' },
});

const mStyles = StyleSheet.create({
  body: { padding: 24, paddingTop: 64 },
  prodHeader: { flexDirection: 'row', gap: 14, alignItems: 'flex-start', marginBottom: 16 },
  prodName: { fontSize: 17, fontWeight: '800', color: C.navy, lineHeight: 22, marginBottom: 4 },
  prodPrice: { fontSize: 13, fontWeight: '700', color: C.orange },
  secureNote: {
    backgroundColor: '#f0fdf4',
    borderRadius: RADIUS.md,
    padding: 12,
    borderWidth: 1, borderColor: '#bbf7d0',
    marginBottom: 18,
  },
  secureText: { fontSize: 13, fontWeight: '600', color: C.green, lineHeight: 19 },
  row: { flexDirection: 'row', marginBottom: 0 },
  label: { fontSize: 12.5, fontWeight: '700', color: C.navy, marginBottom: 6, marginTop: 8 },
  input: {
    fontSize: 14, padding: 13,
    borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: C.line,
    backgroundColor: C.cream, color: C.dark,
    marginBottom: 0,
  },
  totalRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    backgroundColor: C.cream,
    borderRadius: RADIUS.md,
    padding: 14,
    borderWidth: 1, borderColor: C.line,
  },
  totalLabel: { fontSize: 15, fontWeight: '700', color: C.navy },
  totalVal: { fontSize: 18, fontWeight: '900', color: C.orange },
  doneWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  doneTitle: { fontSize: 24, fontWeight: '900', color: C.navy, marginBottom: 10 },
  doneSub: { fontSize: 14, color: C.mid, textAlign: 'center', lineHeight: 22, marginBottom: 28 },
  closeBtn: {
    backgroundColor: C.orange, borderRadius: RADIUS.md,
    paddingHorizontal: 28, paddingVertical: 14,
  },
  closeBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
