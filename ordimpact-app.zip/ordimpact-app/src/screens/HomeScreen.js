// src/screens/HomeScreen.js

import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Linking, Dimensions, ImageBackground,
} from 'react-native';
import { C, SHADOW, RADIUS } from '../theme';
import { CONTACT } from '../theme';
import { Card, BtnPrimary, BtnWA, Tag, SectionTitle } from '../components/UI';

const { width } = Dimensions.get('window');

const WORDS = ['en Guyane', 'pour les familles', 'pour les pros', 'sans stress'];

const HIGHLIGHTS = [
  { emoji: '🔒', label: 'Discrétion totale' },
  { emoji: '⚡', label: '8 ans d\'expertise' },
  { emoji: '🎯', label: 'Sur mesure' },
  { emoji: '📍', label: 'Guyane française' },
];

const SERVICES_HOME = [
  { icon: '🚘', title: 'Carte grise', sub: 'minute', color: '#E8F4FF' },
  { icon: '🌍', title: 'Immigration', sub: 'dossiers', color: '#FFF4E8' },
  { icon: '🇫🇷', title: 'Naturalisation', sub: 'suivi complet', color: '#EFFFEE' },
  { icon: '📱', title: 'Réseaux sociaux', sub: 'création visuels', color: '#FFF0F5' },
  { icon: '⌨️', title: 'Frappe docs', sub: 'rapide & pro', color: '#F5F0FF' },
  { icon: '🗂️', title: 'Secrétariat', sub: 'à votre service', color: '#F0F9FF' },
];

const STATS = [
  { n: '8', unit: 'ans', label: 'd\'expertise' },
  { n: '500+', unit: '', label: 'clients accompagnés' },
  { n: '97%', unit: '', label: 'de satisfaction' },
  { n: '1j', unit: '', label: 'délai moyen' },
];

export default function HomeScreen({ navigation }) {
  const [wordIdx, setWordIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setWordIdx(i => (i + 1) % WORDS.length), 2600);
    return () => clearInterval(t);
  }, []);

  const openWA = () =>
    Linking.openURL(`https://wa.me/${CONTACT.waNumber}?text=Bonjour, je souhaite un renseignement.`);

  return (
    <ScrollView style={styles.root} showsVerticalScrollIndicator={false}>
      {/* ── HERO ── */}
      <View style={styles.hero}>
        {/* Accent bar gauche */}
        <View style={styles.accentBar} />

        <View style={styles.heroBadge}>
          <View style={styles.heroDot} />
          <Text style={styles.heroBadgeText}>Assistante administrative — Guyane française</Text>
        </View>

        <Text style={styles.heroTitle}>L'administration{'\n'}simplifiée.</Text>

        <View style={styles.heroWordRow}>
          <Text style={styles.heroWord}>{WORDS[wordIdx]}</Text>
          <Text style={styles.heroCursor}>|</Text>
        </View>

        <Text style={styles.heroSub}>
          Parce que la paperasse ne devrait pas vous bloquer — je prends en charge toutes vos démarches
          administratives, de A à Z.
        </Text>

        {/* Highlights */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.hlScroll}>
          {HIGHLIGHTS.map((h, i) => (
            <View key={i} style={styles.hlChip}>
              <Text style={{ fontSize: 14 }}>{h.emoji}</Text>
              <Text style={styles.hlLabel}>{h.label}</Text>
            </View>
          ))}
        </ScrollView>

        {/* CTA buttons */}
        <BtnPrimary
          label="✨ Diagnostic gratuit →"
          onPress={() => navigation.navigate('Réserver')}
          style={{ marginBottom: 12 }}
        />
        <BtnWA label="WhatsApp" onPress={openWA} />
      </View>

      {/* ── STATS ── */}
      <View style={styles.statsRow}>
        {STATS.map((s, i) => (
          <View key={i} style={styles.statItem}>
            <Text style={styles.statN}>{s.n}<Text style={styles.statUnit}>{s.unit}</Text></Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* ── SERVICES GRID ── */}
      <View style={styles.section}>
        <SectionTitle
          title="Nos services"
          sub="Administratif, digital, sur-mesure."
        />
        <View style={styles.svcGrid}>
          {SERVICES_HOME.map((s, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.svcCard, { backgroundColor: s.color }]}
              onPress={() => navigation.navigate('Services')}
              activeOpacity={0.85}
            >
              <Text style={{ fontSize: 28 }}>{s.icon}</Text>
              <Text style={styles.svcTitle}>{s.title}</Text>
              <Text style={styles.svcSub}>{s.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Services')} style={styles.seeAll}>
          <Text style={styles.seeAllText}>Voir tous les services →</Text>
        </TouchableOpacity>
      </View>

      {/* ── À PROPOS ── */}
      <View style={styles.about}>
        <View style={styles.aboutCard}>
          <View style={styles.aboutAvatar}>
            <Text style={{ fontSize: 36 }}>👩🏽‍💼</Text>
          </View>
          <SectionTitle title="8 ans d'expertise à votre service" />
          <Text style={styles.aboutText}>
            Titulaire d'un BAC PRO ARCU (Accueil Relation Client et Usagers) obtenu en 2017,
            j'accompagne particuliers et professionnels en Guyane depuis 8 ans.
          </Text>
          <Text style={styles.aboutMission}>
            Mon objectif : vous éviter les tracas administratifs, vous faire gagner du temps
            et vous redonner la sérénité. Chaque situation est unique — je m'adapte à vous.
          </Text>
          <View style={styles.aboutBadges}>
            {['📋 BAC PRO ARCU 2017', '🏆 500+ clients', '📍 Cayenne, Guyane'].map((b, i) => (
              <View key={i} style={styles.aboutBadge}>
                <Text style={styles.aboutBadgeText}>{b}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      {/* ── BOUTIQUE PROMO ── */}
      <View style={styles.section}>
        <SectionTitle
          title="Boutique en ligne"
          sub="Guides, modèles et outils pratiques."
        />
        <Card onPress={() => navigation.navigate('Boutique')} style={styles.shopPromo}>
          <View style={styles.shopPromoInner}>
            <View style={{ flex: 1 }}>
              <Tag label="Accès immédiat" color={C.green} bg="#f0fdf4" />
              <Text style={styles.shopPromoTitle}>Produits numériques</Text>
              <Text style={styles.shopPromoSub}>Guides, kits, modèles à télécharger dès l'achat.</Text>
              <Text style={styles.shopPromoCta}>Découvrir →</Text>
            </View>
            <Text style={{ fontSize: 52 }}>📦</Text>
          </View>
        </Card>
      </View>

      {/* ── CTA FINAL ── */}
      <View style={styles.ctaFinal}>
        <Text style={styles.ctaTitle}>Prête à vous aider</Text>
        <Text style={styles.ctaSub}>Contactez-moi dès maintenant pour un diagnostic gratuit.</Text>
        <BtnPrimary
          label="Prendre rendez-vous"
          onPress={() => navigation.navigate('Réserver')}
          style={{ marginBottom: 12 }}
        />
        <BtnWA label="Écrire sur WhatsApp" onPress={openWA} />
      </View>

      <View style={{ height: 30 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#fff' },

  /* Hero */
  hero: {
    backgroundColor: C.navy,
    padding: 24,
    paddingTop: 48,
    paddingBottom: 36,
    position: 'relative',
    overflow: 'hidden',
  },
  accentBar: {
    position: 'absolute',
    left: 0, top: '20%',
    width: 4, height: '55%',
    borderRadius: 2,
    backgroundColor: C.orange,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(244,120,32,0.15)',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    alignSelf: 'flex-start',
    marginBottom: 18,
    gap: 7,
  },
  heroDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: C.orange },
  heroBadgeText: { fontSize: 11, fontWeight: '700', color: C.orange, letterSpacing: 0.4 },
  heroTitle: {
    fontSize: 36,
    fontWeight: '900',
    color: '#fff',
    letterSpacing: -1,
    lineHeight: 42,
    marginBottom: 6,
  },
  heroWordRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 18 },
  heroWord: { fontSize: 28, fontWeight: '900', color: C.orange, letterSpacing: -0.5 },
  heroCursor: { fontSize: 28, color: C.orange, marginLeft: 2, opacity: 0.7 },
  heroSub: { fontSize: 14, color: 'rgba(255,255,255,0.7)', lineHeight: 22, marginBottom: 22 },
  hlScroll: { marginBottom: 24 },
  hlChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8,
    marginRight: 8, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  hlLabel: { fontSize: 12, fontWeight: '600', color: 'rgba(255,255,255,0.85)' },

  /* Stats */
  statsRow: {
    flexDirection: 'row',
    backgroundColor: C.orange,
    paddingVertical: 20,
  },
  statItem: { flex: 1, alignItems: 'center' },
  statN: { fontSize: 22, fontWeight: '900', color: '#fff' },
  statUnit: { fontSize: 14, fontWeight: '700', color: 'rgba(255,255,255,0.8)' },
  statLabel: { fontSize: 10, color: 'rgba(255,255,255,0.75)', fontWeight: '600', marginTop: 2, textAlign: 'center' },

  /* Section */
  section: { padding: 24 },

  /* Services grid */
  svcGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 },
  svcCard: {
    width: (width - 58) / 2,
    borderRadius: RADIUS.lg,
    padding: 16,
    gap: 6,
    ...SHADOW.sm,
  },
  svcTitle: { fontSize: 14, fontWeight: '800', color: C.navy },
  svcSub: { fontSize: 11, color: C.mid, fontWeight: '500' },
  seeAll: { alignSelf: 'center', padding: 8 },
  seeAllText: { color: C.orange, fontWeight: '700', fontSize: 14 },

  /* À propos */
  about: { backgroundColor: C.cream, padding: 24 },
  aboutCard: { backgroundColor: '#fff', borderRadius: RADIUS.xl, padding: 22, ...SHADOW.sm },
  aboutAvatar: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: C.warm,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 16,
  },
  aboutText: { fontSize: 14, color: C.mid, lineHeight: 22, marginBottom: 12 },
  aboutMission: { fontSize: 14, color: C.navy, fontWeight: '600', lineHeight: 22, marginBottom: 16 },
  aboutBadges: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  aboutBadge: {
    backgroundColor: C.warm, borderRadius: RADIUS.full,
    paddingHorizontal: 12, paddingVertical: 5,
    borderWidth: 1, borderColor: '#FDDBB4',
  },
  aboutBadgeText: { fontSize: 11, fontWeight: '700', color: C.orange },

  /* Shop promo */
  shopPromo: { marginBottom: 4 },
  shopPromoInner: { flexDirection: 'row', alignItems: 'center', padding: 20, gap: 16 },
  shopPromoTitle: { fontSize: 18, fontWeight: '800', color: C.navy, marginTop: 8, marginBottom: 4 },
  shopPromoSub: { fontSize: 13, color: C.mid, lineHeight: 19, marginBottom: 10 },
  shopPromoCta: { fontSize: 14, fontWeight: '700', color: C.orange },

  /* CTA Final */
  ctaFinal: {
    backgroundColor: C.navy,
    margin: 24,
    borderRadius: RADIUS.xl,
    padding: 28,
    alignItems: 'center',
    ...SHADOW.lg,
  },
  ctaTitle: { fontSize: 22, fontWeight: '900', color: '#fff', textAlign: 'center', marginBottom: 8 },
  ctaSub: { fontSize: 13, color: 'rgba(255,255,255,0.65)', textAlign: 'center', marginBottom: 24, lineHeight: 20 },
});
