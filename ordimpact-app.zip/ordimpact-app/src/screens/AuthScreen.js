// src/screens/AuthScreen.js — Espace client ORD'IMPACT

import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  TextInput, Alert,
} from 'react-native';
import { C, RADIUS, SHADOW } from '../theme';
import { BtnPrimary, Card } from '../components/UI';

const ADMIN_EMAIL = 'ordimpact@gmail.com';
const ADMIN_PASS  = 'admin2024';

/* Simule un espace client simple */
const DEMO_CLIENTS = {
  'client@demo.fr': {
    prenom: 'Marie',
    nom: 'Dupont',
    dossiers: [
      { id: 'D-001', service: 'Carte grise minute', status: 'En cours', date: '10/04/2026', progress: 65 },
      { id: 'D-002', service: 'Création de visuels', status: 'Terminé', date: '28/03/2026', progress: 100 },
    ],
    factures: [
      { id: 'OI-2026-001', montant: 35, service: 'Carte grise minute', date: '10/04/2026', paid: false },
      { id: 'OI-2025-012', montant: 30, service: 'Visuels réseaux sociaux', date: '28/03/2026', paid: true },
    ],
  },
};

const STATUS_COLORS = {
  'En cours': C.amber,
  'Terminé': C.green,
  'En attente': C.blue,
};

function DossierCard({ d }) {
  return (
    <View style={styles.dossierCard}>
      <View style={styles.dossierRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.dossierRef}>{d.id}</Text>
          <Text style={styles.dossierSvc}>{d.service}</Text>
          <Text style={styles.dossierDate}>📅 {d.date}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: STATUS_COLORS[d.status] + '18' }]}>
          <Text style={[styles.statusText, { color: STATUS_COLORS[d.status] }]}>{d.status}</Text>
        </View>
      </View>
      <View style={styles.progressBar}>
        <View style={[styles.progressFill, { width: `${d.progress}%`, backgroundColor: STATUS_COLORS[d.status] }]} />
      </View>
      <Text style={styles.progressLabel}>{d.progress}% complété</Text>
    </View>
  );
}

function FactureCard({ f }) {
  return (
    <View style={styles.factureCard}>
      <View style={styles.factureRow}>
        <View style={{ flex: 1 }}>
          <Text style={styles.factureRef}>{f.id}</Text>
          <Text style={styles.factureSvc}>{f.service}</Text>
          <Text style={styles.factureDate}>{f.date}</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={styles.factureMontant}>{f.montant} €</Text>
          <View style={[styles.statusBadge, { backgroundColor: f.paid ? '#f0fdf4' : '#fef2f2' }]}>
            <Text style={[styles.statusText, { color: f.paid ? C.green : C.red }]}>
              {f.paid ? '✓ Payée' : '⚠ Impayée'}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

function ClientSpace({ user, onLogout }) {
  const [tab, setTab] = useState(0);
  const TABS = ['Mes dossiers', 'Mes factures'];

  return (
    <View style={{ flex: 1 }}>
      {/* Header client */}
      <View style={styles.clientHeader}>
        <View style={styles.clientAvatar}>
          <Text style={{ fontSize: 28 }}>👤</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.clientName}>{user.prenom} {user.nom}</Text>
          <Text style={styles.clientRole}>Espace client ORD'IMPACT</Text>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={onLogout}>
          <Text style={styles.logoutText}>↩ Déco.</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.clientTabs}>
        {TABS.map((t, i) => (
          <TouchableOpacity key={i} style={[styles.clientTab, tab === i && styles.clientTabOn]} onPress={() => setTab(i)}>
            <Text style={[styles.clientTabText, tab === i && styles.clientTabTextOn]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.clientScroll} showsVerticalScrollIndicator={false}>
        {tab === 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>{user.dossiers.length} dossier(s) actif(s)</Text>
            {user.dossiers.map(d => <DossierCard key={d.id} d={d} />)}
          </View>
        )}
        {tab === 1 && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>{user.factures.length} facture(s)</Text>
            {user.factures.map(f => <FactureCard key={f.id} f={f} />)}
            <View style={styles.factureTotal}>
              <Text style={styles.factureTotalLabel}>Total en attente</Text>
              <Text style={styles.factureTotalVal}>
                {user.factures.filter(f => !f.paid).reduce((s, f) => s + f.montant, 0)} €
              </Text>
            </View>
          </View>
        )}
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

export default function AuthScreen() {
  const [mode, setMode] = useState('login'); // login | register
  const [form, setForm] = useState({ email: '', password: '', prenom: '', nom: '' });
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState(null);

  const upd = k => v => setForm(f => ({ ...f, [k]: v }));

  const inputStyle = (key) => [
    styles.input,
    focused === key && styles.inputFocused,
  ];

  const handleLogin = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));

    if (form.email === ADMIN_EMAIL && form.password === ADMIN_PASS) {
      setUser({ prenom: 'Chawanda', nom: 'ORD\'IMPACT', dossiers: [], factures: [], isAdmin: true });
    } else if (DEMO_CLIENTS[form.email]) {
      setUser(DEMO_CLIENTS[form.email]);
    } else {
      Alert.alert('Connexion échouée', 'Email ou mot de passe incorrect.\n\nEssayez : client@demo.fr / demo1234');
    }
    setLoading(false);
  };

  if (user) {
    return <ClientSpace user={user} onLogout={() => setUser(null)} />;
  }

  return (
    <ScrollView style={styles.root} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Espace client</Text>
        <Text style={styles.headerSub}>Suivez vos dossiers et factures.</Text>
      </View>

      <View style={styles.form}>
        {/* Toggle */}
        <View style={styles.modeRow}>
          {['Connexion', 'Créer un compte'].map((m, i) => (
            <TouchableOpacity
              key={m}
              style={[styles.modeBtn, mode === (i === 0 ? 'login' : 'register') && styles.modeBtnOn]}
              onPress={() => setMode(i === 0 ? 'login' : 'register')}
              activeOpacity={0.82}
            >
              <Text style={[styles.modeBtnText, mode === (i === 0 ? 'login' : 'register') && styles.modeBtnTextOn]}>{m}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {mode === 'register' && (
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Prénom</Text>
              <TextInput style={inputStyle('prenom')} value={form.prenom} onChangeText={upd('prenom')} placeholder="Marie" placeholderTextColor={C.muted} onFocus={() => setFocused('prenom')} onBlur={() => setFocused(null)} />
            </View>
            <View style={{ width: 10 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Nom</Text>
              <TextInput style={inputStyle('nom')} value={form.nom} onChangeText={upd('nom')} placeholder="Dupont" placeholderTextColor={C.muted} onFocus={() => setFocused('nom')} onBlur={() => setFocused(null)} />
            </View>
          </View>
        )}

        <Text style={styles.label}>Email</Text>
        <TextInput
          style={inputStyle('email')}
          value={form.email}
          onChangeText={upd('email')}
          placeholder="votre@email.fr"
          placeholderTextColor={C.muted}
          keyboardType="email-address"
          autoCapitalize="none"
          onFocus={() => setFocused('email')}
          onBlur={() => setFocused(null)}
        />

        <Text style={styles.label}>Mot de passe</Text>
        <TextInput
          style={[inputStyle('pass'), { marginBottom: 22 }]}
          value={form.password}
          onChangeText={upd('password')}
          placeholder="••••••••"
          placeholderTextColor={C.muted}
          secureTextEntry
          onFocus={() => setFocused('pass')}
          onBlur={() => setFocused(null)}
        />

        <BtnPrimary
          label={loading ? '…' : mode === 'login' ? 'Se connecter' : 'Créer mon compte'}
          onPress={handleLogin}
          disabled={!form.email || !form.password || loading}
        />

        {/* Demo hint */}
        <View style={styles.demoHint}>
          <Text style={styles.demoHintTitle}>💡 Compte démo client</Text>
          <Text style={styles.demoHintText}>Email : client@demo.fr{'\n'}Mot de passe : n'importe lequel</Text>
        </View>

        {/* Info si pas de compte */}
        <View style={styles.noAccountBlock}>
          <Text style={styles.noAccountText}>
            Pas encore client ? Réservez un diagnostic gratuit et votre compte sera créé automatiquement.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.cream },
  header: {
    backgroundColor: C.navy,
    paddingHorizontal: 20,
    paddingTop: 48,
    paddingBottom: 28,
  },
  headerTitle: { fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -0.5 },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 5 },

  form: { padding: 20 },
  modeRow: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: RADIUS.md,
    borderWidth: 1.5,
    borderColor: C.line,
    padding: 4,
    marginBottom: 24,
  },
  modeBtn: { flex: 1, paddingVertical: 10, borderRadius: RADIUS.sm, alignItems: 'center' },
  modeBtnOn: { backgroundColor: C.orange },
  modeBtnText: { fontSize: 13, fontWeight: '600', color: C.muted },
  modeBtnTextOn: { color: '#fff', fontWeight: '700' },

  row: { flexDirection: 'row', marginBottom: 0 },
  label: { fontSize: 12.5, fontWeight: '700', color: C.navy, marginBottom: 7, marginTop: 12 },
  input: {
    fontSize: 14, padding: 13,
    borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: C.line,
    backgroundColor: '#fff', color: C.dark,
    marginBottom: 0,
  },
  inputFocused: { borderColor: C.blue, backgroundColor: '#f8fbff' },

  demoHint: {
    backgroundColor: '#EFF6FF',
    borderRadius: RADIUS.lg,
    padding: 14,
    borderWidth: 1, borderColor: '#BFDBFE',
    marginTop: 20,
  },
  demoHintTitle: { fontSize: 13, fontWeight: '700', color: C.blue, marginBottom: 6 },
  demoHintText: { fontSize: 12, color: C.mid, lineHeight: 20 },

  noAccountBlock: {
    backgroundColor: C.warm,
    borderRadius: RADIUS.lg,
    padding: 16,
    marginTop: 12,
    borderWidth: 1, borderColor: '#FDDBB4',
  },
  noAccountText: { fontSize: 13, color: C.mid, lineHeight: 20, textAlign: 'center' },

  /* Client space */
  clientHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: C.navy,
    paddingHorizontal: 20, paddingTop: 48, paddingBottom: 22,
  },
  clientAvatar: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center', justifyContent: 'center',
  },
  clientName: { fontSize: 18, fontWeight: '900', color: '#fff' },
  clientRole: { fontSize: 11, color: 'rgba(255,255,255,0.55)', fontWeight: '500', marginTop: 2 },
  logoutBtn: {
    paddingHorizontal: 12, paddingVertical: 7,
    borderRadius: RADIUS.md,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
  },
  logoutText: { fontSize: 12, fontWeight: '600', color: 'rgba(255,255,255,0.6)' },

  clientTabs: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1, borderBottomColor: C.line,
  },
  clientTab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  clientTabOn: { borderBottomWidth: 2, borderBottomColor: C.orange },
  clientTabText: { fontSize: 13, fontWeight: '600', color: C.muted },
  clientTabTextOn: { color: C.navy, fontWeight: '700' },
  clientScroll: { flex: 1, backgroundColor: C.cream },

  section: { padding: 16, gap: 10 },
  sectionLabel: { fontSize: 12, fontWeight: '700', color: C.muted, letterSpacing: 0.5, textTransform: 'uppercase' },

  dossierCard: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.lg,
    padding: 16,
    borderWidth: 1.5, borderColor: C.line,
    ...SHADOW.sm,
  },
  dossierRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 12 },
  dossierRef: { fontSize: 11, fontWeight: '700', color: C.muted, letterSpacing: 0.5, marginBottom: 3 },
  dossierSvc: { fontSize: 14, fontWeight: '800', color: C.navy, marginBottom: 4 },
  dossierDate: { fontSize: 11, color: C.muted },
  statusBadge: {
    borderRadius: RADIUS.full,
    paddingHorizontal: 10, paddingVertical: 4,
    alignSelf: 'flex-start',
  },
  statusText: { fontSize: 12, fontWeight: '700' },
  progressBar: {
    height: 5, borderRadius: 3,
    backgroundColor: C.line,
    overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: 3 },
  progressLabel: { fontSize: 11, color: C.muted, marginTop: 5, fontWeight: '500' },

  factureCard: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.lg,
    padding: 16,
    borderWidth: 1.5, borderColor: C.line,
    ...SHADOW.sm,
  },
  factureRow: { flexDirection: 'row', alignItems: 'center' },
  factureRef: { fontSize: 11, fontWeight: '700', color: C.muted, marginBottom: 3 },
  factureSvc: { fontSize: 14, fontWeight: '700', color: C.navy, marginBottom: 3 },
  factureDate: { fontSize: 11, color: C.muted },
  factureMontant: { fontSize: 18, fontWeight: '900', color: C.navy, marginBottom: 6 },

  factureTotal: {
    backgroundColor: C.warm,
    borderRadius: RADIUS.md,
    padding: 14,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderWidth: 1, borderColor: '#FDDBB4',
    marginTop: 4,
  },
  factureTotalLabel: { fontSize: 14, fontWeight: '700', color: C.mid },
  factureTotalVal: { fontSize: 20, fontWeight: '900', color: C.orange },
});
