// src/theme.js — Charte graphique ORD'IMPACT

export const C = {
  navy:    '#001E50',
  navy2:   '#0A1B45',
  orange:  '#F47820',
  orange2: '#F05A1E',
  blue:    '#1E78B4',
  cyan:    '#1E96D2',
  pale:    '#B4D2F0',
  cream:   '#F7F9FC',
  warm:    '#FFF7ED',
  line:    '#E4EBF5',
  mid:     '#64748B',
  muted:   '#94A3B8',
  dark:    '#0A1628',
  green:   '#16A34A',
  red:     '#DC2626',
  amber:   '#D97706',
  purple:  '#7C3AED',
  white:   '#FFFFFF',
};

export const CONTACT = {
  phone:     '0694473322',
  phoneDisplay: '06 94 47 33 22',
  email:     'ordimpact@gmail.com',
  waNumber:  '33694473322',
  instagram: 'https://www.instagram.com/ordimpact',
  address:   '44 Rue Albert Darnal, 97300 Cayenne',
};

export const FONTS = {
  regular: { fontWeight: '400' },
  medium:  { fontWeight: '500' },
  bold:    { fontWeight: '700' },
  black:   { fontWeight: '900' },
};

export const RADIUS = {
  sm:  8,
  md:  12,
  lg:  16,
  xl:  22,
  full: 999,
};

export const SHADOW = {
  sm: {
    shadowColor: '#001E50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  md: {
    shadowColor: '#001E50',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 6,
  },
  lg: {
    shadowColor: '#001E50',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.18,
    shadowRadius: 28,
    elevation: 10,
  },
};
