// src/data.js — Données services & boutique ORD'IMPACT

export const SERVICES_PRESENTIELS = [
  { id: 'admin',       icon: '📋', label: 'Assistance administrative générale', price: 'Sur devis',          desc: 'Accompagnement complet de vos démarches administratives.' },
  { id: 'cession',     icon: '🚗', label: 'Cession de véhicule',                price: 'Sur devis',          desc: 'Rédaction et suivi du contrat de cession.' },
  { id: 'naturalisa',  icon: '🇫🇷', label: 'Dossier de naturalisation',          price: 'Sur devis',          desc: 'Constitution et suivi de votre dossier de naturalisation.' },
  { id: 'permis',      icon: '🪪', label: 'Duplicata de permis de conduire',    price: 'À partir de 25 €',   desc: 'Déclaration de perte et demande de duplicata.' },
  { id: 'cartegrise',  icon: '🚘', label: 'Carte grise minute',                 price: 'À partir de 35 €',   desc: 'Immatriculation rapide, même le jour même.' },
  { id: 'immigr',      icon: '🌍', label: "Procédure d'immigration",            price: 'Sur devis',          desc: 'Titre de séjour, regroupement familial, etc.' },
  { id: 'secretariat', icon: '🗂️', label: 'Secrétariat administratif',          price: 'À partir de 20 €/h', desc: 'Rédaction, classement, courriers officiels.' },
  { id: 'dpae',        icon: '📝', label: 'DPAE — Déclaration préalable',       price: '20 € / DPAE',        desc: 'Déclaration préalable à l\'embauche auprès de l\'URSSAF.' },
];

export const SERVICES_DIGITAUX = [
  { id: 'visuels',     icon: '📱', label: 'Création de visuels & réseaux sociaux', price: 'À partir de 30 €',      desc: 'Posts, stories et visuels pro pour vos réseaux.' },
  { id: 'frappe',      icon: '⌨️', label: 'Frappe de documents',                   price: 'À partir de 15 €',      desc: 'Retranscription et mise en forme de vos documents.' },
  { id: 'reseaux',     icon: '📲', label: 'Gestion de vos réseaux sociaux',        price: 'À partir de 80 €/mois', desc: 'Animation complète de vos comptes Instagram, Facebook, etc.' },
  { id: 'signature',   icon: '✉️', label: 'Signature email professionnelle',        price: 'À partir de 20 €',      desc: 'Signature HTML personnalisée aux couleurs de votre marque.' },
  { id: 'banniere',    icon: '🖼️', label: 'Bannière',                              price: 'À partir de 25 €',      desc: 'Bannière de profil ou de couverture personnalisée.' },
  { id: 'flyers',      icon: '📄', label: 'Flyers',                                price: 'À partir de 30 €',      desc: 'Flyers professionnels prêts à imprimer.' },
  { id: 'cartevisite', icon: '💼', label: 'Carte de visite virtuelle & interactive',price: 'À partir de 35 €',      desc: 'Carte de visite numérique partageable en un lien.' },
  { id: 'menu',        icon: '🍽️', label: 'Menu interactif',                       price: 'À partir de 120 €',     desc: 'Menu QR code pour restaurants et commerces.' },
  { id: 'fichepr',     icon: '📦', label: 'Fiche produit',                         price: 'À partir de 20 €/fiche', desc: 'Fiches produits optimisées pour la vente en ligne.' },
];

export const DIGITAL_PRODUCTS = [
  { id: 1, emoji: '📂', name: 'Kit Organisation Documents',  price: 15, cat: 'Organisation', desc: 'Checklist + modèles de classement numérique. Accès immédiat après paiement.' },
  { id: 2, emoji: '✉️', name: 'Pack Lettres Administratives', price: 9,  cat: 'Courrier',      desc: '5 modèles prêts à l\'emploi pour toutes les situations.' },
  { id: 3, emoji: '🏠', name: 'Guide CAF / APL Pas à Pas',    price: 12, cat: 'Guides',        desc: 'Guide illustré étape par étape pour vos démarches CAF.' },
  { id: 4, emoji: '💰', name: 'Tableau Budget Familial',       price: 8,  cat: 'Organisation', desc: 'Fichier Excel pré-formaté, calculs automatiques.' },
  { id: 5, emoji: '📋', name: 'Guide Impôts en Guyane',        price: 14, cat: 'Guides',        desc: 'Déclaration de revenus expliquée pas à pas pour la Guyane.' },
];

export const PHYSIQUE_PRODUCTS = [
  { id: 101, emoji: '📁', name: 'Chemise à soufflet A4',      price: 4.99, cat: 'Papeterie',  desc: 'Classement de documents, coloris assortis.' },
  { id: 102, emoji: '📚', name: 'Classeur à anneaux A4',      price: 7.99, cat: 'Classement', desc: 'Classeur rigide 8 cm, idéal pour archivage.' },
  { id: 103, emoji: '🗃️', name: 'Pochettes plastiques ×100',  price: 9.99, cat: 'Classement', desc: 'Pochettes perforées transparentes A4.' },
  { id: 104, emoji: '🏷️', name: 'Étiquettes autocollantes ×540', price: 6.99, cat: 'Papeterie', desc: 'Étiquettes blanches pour classement.' },
];

export const PHONE_PREFIXES = [
  { code: '+594', flag: '🇬🇫', label: 'Guyane' },
  { code: '+33',  flag: '🇫🇷', label: 'France' },
  { code: '+596', flag: '🇲🇶', label: 'Martinique' },
  { code: '+590', flag: '🇬🇵', label: 'Guadeloupe' },
  { code: '+262', flag: '🇷🇪', label: 'Réunion' },
  { code: '+55',  flag: '🇧🇷', label: 'Brésil' },
  { code: '+1',   flag: '🇺🇸', label: 'USA' },
];
