// src/components/UI.js — Composants réutilisables ORD'IMPACT

import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
} from 'react-native';
import { C, RADIUS, SHADOW } from '../theme';

/* ── Logo SVG-like (rendu natif) ── */
export function LogoBadge({ size = 48 }) {
  return (
    <View style={[styles.logoBadge, { width: size, height: size, borderRadius: size / 2 }]}>
      <Text style={{ fontSize: size * 0.45 }}>OI</Text>
    </View>
  );
}

/* ── Bouton principal orange ── */
export function BtnPrimary({ label, onPress, disabled, loading, style }) {
  return (
    <TouchableOpacity
      style={[styles.btnPrimary, disabled && { opacity: 0.45 }, style]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.82}
    >
      {loading
        ? <ActivityIndicator color="#fff" size="small" />
        : <Text style={styles.btnPrimaryText}>{label}</Text>
      }
    </TouchableOpacity>
  );
}

/* ── Bouton secondaire (outline) ── */
export function BtnOutline({ label, onPress, style }) {
  return (
    <TouchableOpacity style={[styles.btnOutline, style]} onPress={onPress} activeOpacity={0.82}>
      <Text style={styles.btnOutlineText}>{label}</Text>
    </TouchableOpacity>
  );
}

/* ── Bouton WhatsApp vert ── */
export function BtnWA({ label, onPress, style }) {
  return (
    <TouchableOpacity style={[styles.btnWA, style]} onPress={onPress} activeOpacity={0.82}>
      <Text style={styles.btnWAText}>💬 {label}</Text>
    </TouchableOpacity>
  );
}

/* ── Carte générique ── */
export function Card({ children, style, onPress }) {
  const Wrap = onPress ? TouchableOpacity : View;
  return (
    <Wrap
      style={[styles.card, SHADOW.sm, style]}
      onPress={onPress}
      activeOpacity={0.88}
    >
      {children}
    </Wrap>
  );
}

/* ── Badge tag ── */
export function Tag({ label, color = C.orange, bg }) {
  return (
    <View style={[styles.tag, { backgroundColor: bg || C.warm }]}>
      <Text style={[styles.tagText, { color }]}>{label}</Text>
    </View>
  );
}

/* ── Séparateur ── */
export function Divider({ style }) {
  return <View style={[styles.divider, style]} />;
}

/* ── Section titre ── */
export function SectionTitle({ title, sub, center }) {
  return (
    <View style={[styles.sectionTitle, center && { alignItems: 'center' }]}>
      <View style={[styles.divLine, center && { alignSelf: 'center' }]} />
      <Text style={[styles.sTitle, center && { textAlign: 'center' }]}>{title}</Text>
      {sub ? <Text style={[styles.sSub, center && { textAlign: 'center' }]}>{sub}</Text> : null}
    </View>
  );
}

/* ── Icône ronde ── */
export function IconCircle({ emoji, size = 44, bg = C.warm }) {
  return (
    <View style={[styles.iconCircle, { width: size, height: size, borderRadius: size / 2, backgroundColor: bg }]}>
      <Text style={{ fontSize: size * 0.45 }}>{emoji}</Text>
    </View>
  );
}

/* ── Price badge ── */
export function PriceBadge({ price }) {
  return (
    <View style={styles.priceBadge}>
      <Text style={styles.priceText}>{price}</Text>
    </View>
  );
}

/* ── Header écran ── */
export function ScreenHeader({ title, sub }) {
  return (
    <View style={styles.screenHeader}>
      <Text style={styles.screenTitle}>{title}</Text>
      {sub ? <Text style={styles.screenSub}>{sub}</Text> : null}
    </View>
  );
}

/* ── Styles ── */
const styles = StyleSheet.create({
  logoBadge: {
    backgroundColor: C.navy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnPrimary: {
    backgroundColor: C.orange,
    borderRadius: RADIUS.md,
    paddingVertical: 14,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnPrimaryText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 15,
  },
  btnOutline: {
    borderWidth: 2,
    borderColor: C.navy,
    borderRadius: RADIUS.md,
    paddingVertical: 12,
    paddingHorizontal: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnOutlineText: {
    color: C.navy,
    fontWeight: '600',
    fontSize: 14,
  },
  btnWA: {
    backgroundColor: '#25D366',
    borderRadius: RADIUS.md,
    paddingVertical: 13,
    paddingHorizontal: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnWAText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 14,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: RADIUS.lg,
    borderWidth: 1.5,
    borderColor: C.line,
    overflow: 'hidden',
  },
  tag: {
    borderRadius: RADIUS.full,
    paddingHorizontal: 10,
    paddingVertical: 3,
    alignSelf: 'flex-start',
  },
  tagText: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  divider: {
    height: 1,
    backgroundColor: C.line,
    marginVertical: 16,
  },
  sectionTitle: {
    marginBottom: 20,
  },
  divLine: {
    width: 36,
    height: 3,
    backgroundColor: C.orange,
    borderRadius: 2,
    marginBottom: 10,
  },
  sTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: C.navy,
    letterSpacing: -0.5,
    lineHeight: 30,
  },
  sSub: {
    fontSize: 14,
    color: C.mid,
    marginTop: 6,
    lineHeight: 21,
  },
  iconCircle: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  priceBadge: {
    backgroundColor: C.warm,
    borderRadius: RADIUS.full,
    paddingHorizontal: 12,
    paddingVertical: 4,
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: '#FDDBB4',
  },
  priceText: {
    fontSize: 12,
    fontWeight: '700',
    color: C.orange,
  },
  screenHeader: {
    backgroundColor: C.navy,
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 28,
  },
  screenTitle: {
    fontSize: 28,
    fontWeight: '900',
    color: '#fff',
    letterSpacing: -0.5,
  },
  screenSub: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.6)',
    marginTop: 6,
    lineHeight: 19,
  },
});
